module Main where

import Lib
import Data.Char
import Data.Colour
import Graphics.Gloss
import Graphics.Gloss.Interface.Pure.Game 
import qualified Data.Map as Map
import Data.Maybe

-- run here

main :: IO ()
main = do
        knightMonad <- loadBMP "assets/knightW.bmp"
        kingMonad <- loadBMP "assets/kingBNoMonads.bmp"
        whitePawn <- loadBMP "assets/pawnW.bmp"
        blackPawn <- loadBMP "assets/pawnB.bmp"
        whiteKnight <- loadBMP "assets/knightWO.bmp"
        blackKnight <- loadBMP "assets/knightB.bmp"
        whiteRook <- loadBMP "assets/rookW.bmp"
        blackRook <- loadBMP "assets/rookB.bmp"
        whiteBishop <- loadBMP "assets/bishopW.bmp"
        blackBishop <- loadBMP "assets/bishopB.bmp"
        whiteKing <- loadBMP "assets/kingW.bmp"
        blackKing <- loadBMP "assets/kingB.bmp"
        whiteQueen <- loadBMP "assets/queenW.bmp"
        blackQueen <- loadBMP "assets/queenB.bmp"
        let imageAssets = [knightMonad, kingMonad, whitePawn, blackPawn, whiteKnight, blackKnight, whiteRook, blackRook, whiteBishop, blackBishop, whiteKing, blackKing, whiteQueen, blackQueen]
        display window backgroundColour (drawWorld imageAssets (board initialBoard)) 

        



-- handling actions performed on pieces

insertPiece :: PiecePosition -> Piece -> Board -> Board
insertPiece = Map.insert

checkPosition :: PiecePosition -> Board -> Maybe Piece
checkPosition = Map.lookup

movePiece :: (Piece -> Piece) -> PiecePosition -> Board -> Board
movePiece = Map.adjust

removePiece :: PiecePosition -> Board -> Board
removePiece = Map.delete

adjustPosition :: PiecePosition -> PiecePosition -> Board -> Board
adjustPosition position newPosition board = insertPiece newPosition (fromJust $ checkPosition position board) $ removePiece position board


-- way of translating board moves to update game state

-- method of checking for a "check" state on an opposing player's king

-- definitions of pieces and the board as a map containing a set of coordinates mapped to each piece
type Board = Map.Map PiecePosition Piece
type PiecePosition = (Int, Int)

-- defining the different states of each piece
data PieceSide  = White       | Black                               deriving (Eq, Show)
data PieceType  = Knight      | Rook | Bishop | Queen | King | Pawn deriving (Eq, Show)
data PieceState = ActiveMoved | ActiveInitial                       deriving (Eq, Show)

-- defining variables for game state
data State  = CurrentState {   board         :: Board
                             , currentTurn   :: PieceSide }

-- defintion of pieces e.g. is it a rook or pawn and what side is the piece on
-- piece state defined specifically to check if a pawn has moved yet
data Piece = Piece { pieceSide :: PieceSide
                    ,pieceType :: PieceType
                    ,pieceState:: PieceState } deriving (Eq, Show)

data NewPosition = NewPosition { piecePosition    :: PiecePosition
                                ,newPiecePosition :: Maybe PiecePosition  } deriving (Eq, Show)

-- definitions if a move made with a piece is valid
-- pawns can only move forward twice on their first move
isValidMove :: Piece -> PiecePosition -> PiecePosition -> Bool
isValidMove (Piece _ King _)                 (x1, y1) (x2, y2) = abs (x1 - x2) <= 1 && abs (y1 - y2) <= 1
isValidMove (Piece _ Queen _)                (x1, y1) (x2, y2) = (x1 - x2 == 0 || y1 - y2 == 0) || abs (x1 - x2) == abs (y1 - y2)
isValidMove (Piece _ Rook _)                 (x1, y1) (x2, y2) = x1 - x2 == 0 || y1 - y2 == 0
isValidMove (Piece _ Bishop _)               (x1, y1) (x2, y2) = abs (x1 - x2) == abs (y1 - y2)
isValidMove (Piece _ Knight _)               (x1, y1) (x2, y2) = (abs (x1 - x2) == 2 && abs (y1 - y2) == 1) || (abs (y1 - y2) == 2 && abs (x1 - x2) == 1)
isValidMove (Piece White Pawn ActiveInitial) (x1, y1) (x2, y2) = x1 - x2 == 0 && y1 - y2 == -2
isValidMove (Piece Black Pawn ActiveInitial) (x1, y1) (x2, y2) = x1 - x2 == 0 && y1 - y2 == 2
isValidMove (Piece White Pawn ActiveMoved)   (x1, y1) (x2, y2) = x1 - x2 == 0 && y1 - y2 == -1
isValidMove (Piece Black Pawn ActiveMoved)   (x1, y1) (x2, y2) = x1 - x2 == 0 && y1 - y2 == 1

-- defines the capture mechanic
-- special definition for pawns to capture on the diagonal
isValidCapture :: Piece -> PiecePosition -> PiecePosition -> Bool
isValidCapture (Piece White Pawn _) (x1, y1) (x2, y2) = abs (x1 - x2) == 1 && y1 - y2 == -1
isValidCapture (Piece Black Pawn _) (x1, y1) (x2, y2) = abs (x1 - x2) == 1 && y1 - y2 == 1
isValidCapture piece position newPosition = isValidMove piece position newPosition
                  

-- handling events to make sure a player has made a move with a piece (specifically pawns)
updatePieceState :: PiecePosition -> PiecePosition -> Piece -> Piece
updatePieceState position newPosition piece = if pieceType piece == Pawn then piece {pieceState = ActiveMoved} else piece {pieceState = ActiveInitial}

promotePiece :: PieceType -> Piece -> Piece
promotePiece new piece = piece { pieceType = new }

initialBoard :: State
initialBoard = CurrentState (Map.fromList board) White where
        iW piece = Piece White piece ActiveInitial
        iB piece = Piece Black piece ActiveInitial
        board = zip (zip [0..7] [0, 0, 0, 0, 0, 0, 0, 0]) [iB Rook, iB Knight, iB Bishop, iB Queen, iB King, iB Bishop, iB Knight, iB Rook] ++
                zip (zip [0..7] [1, 1, 1, 1, 1, 1, 1, 1]) [iB Pawn, iB Pawn,   iB Pawn,   iB Pawn,  iB Pawn, iB Pawn,   iB Pawn,   iB Pawn] ++
                zip (zip [0..7] [6, 6, 6, 6, 6, 6, 6, 6]) [iW Pawn, iW Pawn,   iW Pawn,   iW Pawn,  iW Pawn, iW Pawn,   iW Pawn,   iW Pawn] ++
                zip (zip [0..7] [7, 7, 7, 7, 7, 7, 7, 7]) [iW Rook, iW Knight, iW Bishop, iW Queen, iW King, iW Bishop, iW Knight, iW Rook] 
        
                


background :: Color
background = white

boardLayoutHorizontal :: Picture
boardLayoutHorizontal =  translate (-370) 420 (scale 0.532 0.5 (Text "A B C D E F G H"))

verticalNumbers :: Picture
verticalNumbers = Pictures [ number (Text (show (fst char))) (snd char) | char <- zip [1..8] [-375, -275..325]  ]

number :: Picture -> Float -> Picture
number char y = translate (-450) y (scale 0.5 0.532 char)

squares :: Picture
squares = Pictures [ square x y | x<-[-400, -200..200], y<-[-400, -200..200] ] 

shiftedSquares :: Picture
shiftedSquares = Pictures [ square x y | x<-[-300, -100 .. 300], y<-[-300, -100 .. 300] ] 

square :: Float -> Float -> Picture
square x y = Polygon [(x,y), (x+100,y), (x+100,y+100), (x,y+100) ]

frame :: Float -> Float -> Picture
frame x y = rectangleWire x y



drawPieceFromState :: [Picture] -> Board -> Picture
drawPieceFromState graphics state = Pictures [ translate (fromIntegral (fst $ fst x) * 100) (fromIntegral (snd $ fst x) * 100) (scale 0.125 0.125 (whichImage graphics (snd x))) | x <- Map.toList state ] where
        whichImage :: [Picture] -> Piece -> Picture
        whichImage graphics piece | pieceType piece == Pawn &&   pieceSide piece == White = (graphics !! 2)
                                  | pieceType piece == Pawn &&   pieceSide piece == Black = (graphics !! 3)
                                  | pieceType piece == Knight && pieceSide piece == White = (graphics !! 4)
                                  | pieceType piece == Knight && pieceSide piece == Black = (graphics !! 5)
                                  | pieceType piece == Rook &&   pieceSide piece == White = (graphics !! 6)
                                  | pieceType piece == Rook &&   pieceSide piece == Black = (graphics !! 7)
                                  | pieceType piece == Bishop && pieceSide piece == White = (graphics !! 8)
                                  | pieceType piece == Bishop && pieceSide piece == Black = (graphics !! 9)
                                  | pieceType piece == King &&   pieceSide piece == White = (graphics !! 10)
                                  | pieceType piece == King &&   pieceSide piece == Black = (graphics !! 11)
                                  | pieceType piece == Queen &&  pieceSide piece == White = (graphics !! 12)
                                  | pieceType piece == Queen &&  pieceSide piece == Black = (graphics !! 13)

window :: Display
window = InWindow "Haskell Chess" (1000, 1000) (0, 0)

backgroundColour :: Color
backgroundColour = sRGB 188 188 188

drawWorld :: [Picture] -> Board -> Picture
drawWorld graphics state = (squares <> shiftedSquares <> frame 800 800 <> boardLayoutHorizontal <> verticalNumbers <> drawPieceFromState graphics state)


