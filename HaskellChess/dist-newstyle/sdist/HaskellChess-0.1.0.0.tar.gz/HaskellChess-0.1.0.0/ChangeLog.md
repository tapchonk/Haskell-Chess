# Changelog for HaskellChess

## Unreleased changes
